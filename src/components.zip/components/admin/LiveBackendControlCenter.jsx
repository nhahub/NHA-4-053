import React, { useEffect, useMemo, useState } from 'react';
import { RefreshCw, UserPlus, Trash2, CheckCircle2, XCircle, PackagePlus, Truck, Warehouse, FileText, Plus, Eye, Building2, Send, Printer, CalendarClock, BadgeDollarSign } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { platformV1 } from '@/services/platformV1Service';

const initialState = { users: [], applications: [], commodities: [], hubs: [], trucks: [], contracts: [], pickups: [], invoices: [], outbound: [], notifications: [], materialRequests: [], adminMessages: [] };
const HIDDEN_PROFILE_KEYS = new Set(['api_endpoint', 'endpoint', 'route', 'url', 'password', 'remember_token', 'token', 'access_token', 'deleted_at', 'updated_at', 'email_verified_at']);
function sanitizeProfileValue(value) {
  if (Array.isArray(value)) return value.map(sanitizeProfileValue).filter((item) => item !== null && item !== undefined && item !== '');
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value)
      .filter(([key, nested]) => !HIDDEN_PROFILE_KEYS.has(key) && nested !== null && nested !== undefined && nested !== '')
      .map(([key, nested]) => [key, sanitizeProfileValue(nested)]));
  }
  return value;
}
function safeProfileEntries(item = {}) {
  return Object.entries(sanitizeProfileValue(item) || {}).filter(([key, value]) => !HIDDEN_PROFILE_KEYS.has(key) && value !== null && value !== undefined && value !== '');
}


function asArray(value) {
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.data)) return value.data;
  return [];
}

function normalizeSnapshotPayload(snapshot) {
  const root = snapshot?.data?.data || snapshot?.data || snapshot || {};
  const normalized = { ...initialState };
  Object.keys(initialState).forEach((key) => {
    normalized[key] = asArray(root[key]);
  });
  return normalized;
}

function normalizeMessage(message = {}) {
  const nested = typeof message.data === 'string' ? (() => { try { return JSON.parse(message.data); } catch { return {}; } })() : (message.data || {});
  return {
    ...message,
    sender_name: message.sender_name || nested.sender_name || nested.name || message.supplier_name,
    sender_email: message.sender_email || nested.sender_email || nested.email,
    message: message.message || nested.message || nested.question || message.body || message.content,
    status: message.status || (message.replied_at ? 'replied' : 'open'),
  };
}

function valueOf(item, keys, fallback = '—') {
  for (const key of keys) {
    const value = key.split('.').reduce((acc, part) => acc?.[part], item);
    if (value !== undefined && value !== null && value !== '') return value;
  }
  return fallback;
}

function statusClass(status = '') {
  const s = String(status).toLowerCase();
  if (['active', 'completed', 'confirmed', 'paid', 'converted', 'approved', 'available', 'matched', 'matched_reserved', 'fulfilled', 'delivered'].includes(s)) return 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-200 dark:border-emerald-800';
  if (['pending', 'scheduled', 'draft', 'requested', 'in_progress', 'shipped', 'contacted'].includes(s)) return 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-200 dark:border-amber-800';
  if (['rejected', 'cancelled', 'overdue', 'maintenance', 'terminated'].includes(s)) return 'bg-red-50 text-red-700 border-red-200 dark:bg-red-950/40 dark:text-red-200 dark:border-red-800';
  return 'bg-slate-50 text-slate-700 border-slate-200 dark:bg-slate-900 dark:text-slate-200 dark:border-slate-700';
}

function MiniTable({ title, description, items = [], columns, actions, empty, icon: Icon = FileText, onProfile, pageSize = 10 }) {
  const [page, setPage] = useState(0);
  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
  const safePage = Math.min(page, totalPages - 1);
  const visibleItems = items.slice(safePage * pageSize, safePage * pageSize + pageSize);

  useEffect(() => {
    if (page > totalPages - 1) setPage(Math.max(0, totalPages - 1));
  }, [items.length, page, totalPages]);

  return (
    <Card className="overflow-hidden border-border/70 shadow-sm bg-card/95">
      <CardHeader className="bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/20">
        <CardTitle className="flex items-center gap-2 text-base"><Icon className="h-4 w-4 text-emerald-700 dark:text-emerald-300" /> {title}</CardTitle>
        {description && <p className="text-xs text-muted-foreground">{description}</p>}
        <p className="text-[11px] text-muted-foreground">Showing {items.length ? safePage * pageSize + 1 : 0}-{Math.min((safePage + 1) * pageSize, items.length)} of {items.length}. Use Previous / Next to browse records without reloading.</p>
      </CardHeader>
      <CardContent className="p-0">
        {items.length === 0 ? <div className="p-6 text-sm text-muted-foreground">{empty || 'No records yet.'}</div> : (
          <>
            <div className="overflow-x-auto"><table className="w-full text-left text-sm">
              <thead className="bg-muted/60 text-xs uppercase text-muted-foreground"><tr>{columns.map((c) => <th key={c.label} className="px-4 py-3 font-semibold">{c.label}</th>)}<th className="px-4 py-3 font-semibold">Actions</th></tr></thead>
              <tbody>{visibleItems.map((item, index) => (
                <tr key={item.id || item.email || `${title}-${safePage}-${index}`} className="border-t border-border/60 hover:bg-muted/30">
                  {columns.map((c) => <td key={c.label} className="px-4 py-3 align-top">{c.render ? c.render(item) : valueOf(item, c.keys || [c.key])}</td>)}
                  <td className="px-4 py-3 align-top"><div className="flex flex-wrap gap-2"><Button size="sm" variant="outline" onClick={() => onProfile?.(item, title)}><Eye className="mr-1 h-3 w-3" /> Profile</Button>{actions?.(item)}</div></td>
                </tr>
              ))}</tbody>
            </table></div>
            <div className="flex items-center justify-between gap-3 border-t px-4 py-3 text-xs text-muted-foreground">
              <Button size="sm" variant="outline" disabled={safePage === 0} onClick={() => setPage((p) => Math.max(0, p - 1))}>Previous</Button>
              <span>Page {safePage + 1} of {totalPages}</span>
              <Button size="sm" variant="outline" disabled={safePage >= totalPages - 1} onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}>Next</Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

function printProfile(title, item) {
  const fields = Object.entries(item || {}).filter(([, v]) => v !== null && v !== undefined && typeof v !== 'object');
  const html = `<!doctype html><html><head><title>${title}</title><style>body{font-family:Arial;background:#f5faf7;margin:0;color:#122018}.sheet{max-width:900px;margin:30px auto;background:white;border-radius:22px;padding:32px;box-shadow:0 20px 70px rgba(2,44,34,.12)}.brand{display:flex;gap:14px;align-items:center;border-bottom:1px solid #dbeee6;padding-bottom:18px;margin-bottom:22px}.logo{width:54px;height:54px;border-radius:16px;background:linear-gradient(135deg,#059669,#0f766e);display:flex;align-items:center;justify-content:center;color:white;font-size:26px}.name{font-size:26px;font-weight:900}.tag{font-size:11px;letter-spacing:3px;color:#059669;font-weight:800}.title{font-size:28px;font-weight:900;margin:0 0 20px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.row{border:1px solid #e2e8f0;border-radius:14px;padding:14px;background:#fbfefd}.k{font-size:11px;color:#64748b;text-transform:uppercase;font-weight:800;letter-spacing:1px}.v{font-size:15px;font-weight:700;margin-top:6px}.footer{margin-top:24px;color:#64748b;font-size:12px}@media print{body{background:white}.sheet{box-shadow:none;margin:0;max-width:none}}</style></head><body><div class="sheet"><div class="brand"><div class="logo">♻</div><div><div class="name">Waste to Value</div><div class="tag">CIRCULAR ECONOMY PLATFORM</div></div></div><h1 class="title">${title} Profile</h1><div class="grid">${fields.map(([k,v])=>`<div class="row"><div class="k">${k.replaceAll('_',' ')}</div><div class="v">${String(v)}</div></div>`).join('')}</div><div class="footer">Generated from live platform records.</div></div><script>window.print()</script></body></html>`;
  const w = window.open('', '_blank');
  w.document.write(html); w.document.close();
}

function ProfileDialog({ profile, onClose }) {
  if (!profile) return null;
  const { item, title } = profile;
  const entries = safeProfileEntries(item || {});
  const primitive = entries.filter(([, v]) => typeof v !== 'object');
  const nested = entries.filter(([, v]) => typeof v === 'object');
  return (
    <Dialog open={!!profile} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl">
        <DialogHeader><DialogTitle className="flex items-center gap-2"><Building2 className="h-5 w-5 text-emerald-700" /> {title} Profile</DialogTitle></DialogHeader>
        <div className="rounded-2xl border bg-gradient-to-br from-emerald-50 to-white p-4 dark:from-emerald-950/30 dark:to-card">
          <p className="font-bold text-lg">{item.company_name || item.factory_name || item.location || item.title || item.material || item.email || item.invoice_number || `#${item.id}`}</p>
          <p className="text-sm text-muted-foreground">Detailed record view with attributes, related data, notes, status and printable output.</p>
          <Button className="mt-3 rounded-xl" variant="outline" onClick={() => printProfile(title, item)}><Printer className="mr-2 h-4 w-4" /> Print this record</Button>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 max-h-[55vh] overflow-y-auto pr-1">
          {primitive.map(([k, v]) => <div key={k} className="rounded-xl border p-3"><p className="text-[11px] uppercase tracking-wide text-muted-foreground">{k.replaceAll('_', ' ')}</p><p className="text-sm font-semibold break-words">{String(v)}</p></div>)}
          {nested.map(([k, v]) => <div key={k} className="rounded-xl border p-3 sm:col-span-2"><p className="text-[11px] uppercase tracking-wide text-muted-foreground">{k.replaceAll('_', ' ')}</p><pre className="mt-2 whitespace-pre-wrap break-words text-xs text-muted-foreground">{JSON.stringify(v, null, 2)}</pre></div>)}
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function LivePlatformControlCenter() {
  const [data, setData] = useState(initialState);
  const [loading, setLoading] = useState(false);
  const [lastMessage, setLastMessage] = useState('Ready. Platform records are synchronized.');
  const [profile, setProfile] = useState(null);
  const [userForm, setUserForm] = useState({ fname: 'New', lname: 'Supplier', email: `supplier${Date.now()}@wastetovalue.local`, phone: '+20 100 555 1234', role: 'supplier', employee_role: 'driver', company_name: 'New Supplier Company', commodity_id: '', password: 'Waste@2026' });
  const [materialForm, setMaterialForm] = useState({ title: 'Textile Waste' });
  const [priceForm, setPriceForm] = useState({ commodity_id: '', price: 4.5 });
  const [hubForm, setHubForm] = useState({ location: 'New Circular Hub', size_sq_meters: 1000, capacity: 50000 });
  const [truckForm, setTruckForm] = useState({ hub_id: '', payload_capacity: 2500, truck_type: 'Box Truck', plate_number: `WTX-${Math.floor(Math.random() * 9000 + 1000)}` });
  const [pickupForm, setPickupForm] = useState({ contract_id: '', hub_id: '', schedule_date: '', estimated_weight: 1000 });
  const [dispatchForm, setDispatchForm] = useState({ truck_id: '', driver_employee_id: '' });
  const [factoryRequestForm, setFactoryRequestForm] = useState({ commodity_id: '', preferred_grade: 'A', quantity_kg: 1200, preferred_delivery_date: '', company_details: 'Admin-created factory request', notes: 'Priority production requirement' });
  const [replyDrafts, setReplyDrafts] = useState({});

  const supplierContracts = useMemo(() => data.contracts.filter((c) => c.party_type === 'supplier' && c.status === 'active'), [data.contracts]);
  const drivers = useMemo(() => data.users.filter((u) => (u.employee?.role || u.role) === 'driver' || u.employee?.role === 'driver'), [data.users]);
  const availableTrucks = useMemo(() => data.trucks.filter((t) => String(t.status).toLowerCase() === 'available'), [data.trucks]);

  async function loadAll(options = {}) {
    if (!options.quiet) setLoading(true);
    try {
      const snapshot = await platformV1.adminLive.snapshot({ fresh: options.fresh ? 1 : undefined, limit: 200 });
      const next = normalizeSnapshotPayload(snapshot);
      next.adminMessages = next.adminMessages.map(normalizeMessage);
      setData(next);
      const firstCommodity = next.commodities[0]?.id || '';
      const firstHub = next.hubs[0]?.id || '';
      const firstSupplierContract = next.contracts.find((c) => c.party_type === 'supplier' && c.status === 'active')?.id || '';
      const firstTruck = next.trucks.find((t) => t.status === 'available')?.id || next.trucks[0]?.id || '';
      const firstDriver = next.users.find((u) => u.employee?.role === 'driver')?.id || '';
      setUserForm((f) => ({ ...f, commodity_id: f.commodity_id || firstCommodity }));
      setTruckForm((f) => ({ ...f, hub_id: f.hub_id || firstHub }));
      setPickupForm((f) => ({ ...f, contract_id: f.contract_id || firstSupplierContract, hub_id: f.hub_id || firstHub, schedule_date: f.schedule_date || new Date(Date.now() + 86400000).toISOString().slice(0, 16) }));
      setFactoryRequestForm((f) => ({ ...f, commodity_id: f.commodity_id || firstCommodity, preferred_delivery_date: f.preferred_delivery_date || new Date(Date.now() + 6 * 86400000).toISOString().slice(0, 10) }));
      setPriceForm((f) => ({ ...f, commodity_id: f.commodity_id || firstCommodity }));
      setDispatchForm((f) => ({ ...f, truck_id: f.truck_id || firstTruck, driver_employee_id: f.driver_employee_id || firstDriver }));
      setLastMessage('Fast snapshot loaded. Data is cached and no request loop is running.');
    } catch (error) {
      setLastMessage(error.message || 'Could not refresh platform data.');
    } finally {
      if (!options.quiet) setLoading(false);
    }
  }

  useEffect(() => { loadAll(); }, []);

  async function runAction(label, action, confirmText = null) {
    if (confirmText && !window.confirm(confirmText)) return;
    setLastMessage(`${label} is running...`);
    try {
      const result = await action();
      setLastMessage(`${label} completed instantly. Data will sync quietly in the background.`);
      window.dispatchEvent(new CustomEvent('wtv-data-mutated'));
      window.clearTimeout(window.__wtvAdminRefreshTimer);
      window.__wtvAdminRefreshTimer = window.setTimeout(() => loadAll({ quiet: true, fresh: true }), 900);
      return result;
    } catch (error) {
      setLastMessage(error.message || `${label} failed.`);
    }
  }

  async function quickEditUser(u) {
    const fname = window.prompt('First name', u.fname || '');
    if (fname === null) return;
    const lname = window.prompt('Last name', u.lname || '');
    if (lname === null) return;
    const email = window.prompt('Email', u.email || '');
    if (email === null) return;
    const companyName = window.prompt('Company / profile name', u.supplier?.company_name || u.factory_profile?.company_name || '');
    await platformV1.users.update(u.id, { fname, lname, email, company_name: companyName || undefined });
  }

  async function createUser() {
    const payload = { ...userForm, email: userForm.email || `user${Date.now()}@wastetovalue.local`, password: userForm.password || 'Waste@2026' };
    if (payload.role === 'employee') { payload.ssn = `SSN-${Date.now()}`; payload.shift = payload.shift || 'morning'; if (payload.employee_role === 'driver') payload.driver_license_number = `DRV-${Date.now()}`; }
    if (payload.role === 'factory') { payload.tax_id = `TAX-${Date.now()}`; payload.required_commodity = data.commodities.find((c) => String(c.id) === String(payload.commodity_id))?.title || 'PET Plastic'; }
    await platformV1.users.create(payload);
    setUserForm((f) => ({ ...f, email: `${f.role}${Date.now()}@wastetovalue.local` }));
  }
  async function createMaterial() { await platformV1.commodities.create(materialForm); setMaterialForm({ title: `New Material ${Date.now().toString().slice(-4)}` }); }
  async function setMaterialPrice() { await platformV1.commodities.setPrice(priceForm.commodity_id, Number(priceForm.price)); }
  async function createHub() { await platformV1.hubs.create(hubForm); }
  async function createTruck() { await platformV1.trucks.create(truckForm); }
  async function createPickup() { await platformV1.pickups.create({ ...pickupForm, schedule_date: new Date(pickupForm.schedule_date).toISOString() }); }
  async function createMaterialRequest() { await platformV1.factory.createMaterialRequest(factoryRequestForm); }
  async function dispatchPickup(id) { await platformV1.pickups.dispatch(id, dispatchForm); }
  async function replyToSupplierMessage(id) {
    const reply = replyDrafts[id]?.trim();
    if (!reply) throw new Error('Write a reply first.');
    await platformV1.adminMessages.reply(id, reply);
    setReplyDrafts((old) => ({ ...old, [id]: '' }));
    setData((old) => ({
      ...old,
      adminMessages: old.adminMessages.filter((message) => Number(message.id) !== Number(id)),
    }));
  }

  return <div className="space-y-6">
    <Card className="border-emerald-200 bg-gradient-to-r from-emerald-50 via-teal-50 to-white shadow-sm dark:from-emerald-950/30 dark:via-teal-950/20 dark:to-card"><CardContent className="flex flex-col gap-4 p-5 lg:flex-row lg:items-center lg:justify-between"><div><div className="mb-2 flex items-center gap-2"><CheckCircle2 className="h-5 w-5 text-emerald-700" /><h2 className="font-heading text-xl font-bold">Platform Control Center</h2></div><p className="max-w-3xl text-sm text-muted-foreground">Live operations: onboarding, users, contracts, pickups, dispatch, material requests, reservations, deliveries, invoices, profiles and printable records.</p><p className="mt-2 text-xs font-semibold text-emerald-700 dark:text-emerald-300">{lastMessage}</p></div><Button onClick={() => loadAll({ fresh: true })} disabled={loading} variant="outline"><RefreshCw className={`mr-2 h-4 w-4 ${loading ? 'animate-spin' : ''}`} /> Refresh Live Data</Button></CardContent></Card>

    <Card><CardHeader><CardTitle className="flex items-center gap-2"><Plus className="h-4 w-4" /> Live creation forms</CardTitle></CardHeader><CardContent className="space-y-3">
      <div className="grid gap-2 md:grid-cols-6"><Input value={userForm.fname} onChange={(e) => setUserForm({ ...userForm, fname: e.target.value })} /><Input value={userForm.lname} onChange={(e) => setUserForm({ ...userForm, lname: e.target.value })} /><Input value={userForm.email} onChange={(e) => setUserForm({ ...userForm, email: e.target.value })} /><select className="h-10 rounded-xl border bg-background px-3 text-sm" value={userForm.role} onChange={(e) => setUserForm({ ...userForm, role: e.target.value })}><option value="supplier">Supplier</option><option value="factory">Factory</option><option value="employee">Employee</option></select><select className="h-10 rounded-xl border bg-background px-3 text-sm" value={userForm.commodity_id} onChange={(e) => setUserForm({ ...userForm, commodity_id: e.target.value })}>{data.commodities.map((m) => <option key={m.id} value={m.id}>{m.title}</option>)}</select><Button onClick={() => runAction('Create user and contract', createUser)}>Add User</Button></div>
      <div className="grid gap-2 md:grid-cols-5"><Input value={materialForm.title} onChange={(e) => setMaterialForm({ title: e.target.value })} /><Button onClick={() => runAction('Create material', createMaterial)}>Add Material</Button><select className="h-10 rounded-xl border bg-background px-3 text-sm" value={priceForm.commodity_id} onChange={(e) => setPriceForm({ ...priceForm, commodity_id: e.target.value })}>{data.commodities.map((m) => <option key={m.id} value={m.id}>{m.title}</option>)}</select><Input type="number" value={priceForm.price} onChange={(e) => setPriceForm({ ...priceForm, price: e.target.value })} /><Button variant="outline" onClick={() => runAction('Set material price', setMaterialPrice)}>Set Price</Button></div>
      <div className="grid gap-2 md:grid-cols-4"><Input value={hubForm.location} onChange={(e) => setHubForm({ ...hubForm, location: e.target.value })} /><Input type="number" value={hubForm.capacity} onChange={(e) => setHubForm({ ...hubForm, capacity: Number(e.target.value) })} /><Input type="number" value={hubForm.size_sq_meters} onChange={(e) => setHubForm({ ...hubForm, size_sq_meters: Number(e.target.value) })} /><Button onClick={() => runAction('Create hub', createHub)}>Add Hub</Button></div>
      <div className="grid gap-2 md:grid-cols-5"><select className="h-10 rounded-xl border bg-background px-3 text-sm" value={truckForm.hub_id} onChange={(e) => setTruckForm({ ...truckForm, hub_id: e.target.value })}>{data.hubs.map((h) => <option key={h.id} value={h.id}>{h.location}</option>)}</select><Input value={truckForm.plate_number} onChange={(e) => setTruckForm({ ...truckForm, plate_number: e.target.value })} /><Input type="number" value={truckForm.payload_capacity} onChange={(e) => setTruckForm({ ...truckForm, payload_capacity: Number(e.target.value) })} /><Input value={truckForm.truck_type} onChange={(e) => setTruckForm({ ...truckForm, truck_type: e.target.value })} /><Button onClick={() => runAction('Create truck', createTruck)}>Add Truck</Button></div>
      <div className="grid gap-2 md:grid-cols-5"><select className="h-10 rounded-xl border bg-background px-3 text-sm" value={pickupForm.contract_id} onChange={(e) => setPickupForm({ ...pickupForm, contract_id: e.target.value })}>{supplierContracts.map((c) => <option key={c.id} value={c.id}>#{c.id} {c.material_type || c.commodity?.title}</option>)}</select><select className="h-10 rounded-xl border bg-background px-3 text-sm" value={pickupForm.hub_id} onChange={(e) => setPickupForm({ ...pickupForm, hub_id: e.target.value })}>{data.hubs.map((h) => <option key={h.id} value={h.id}>{h.location}</option>)}</select><Input type="datetime-local" value={pickupForm.schedule_date} onChange={(e) => setPickupForm({ ...pickupForm, schedule_date: e.target.value })} /><Input type="number" value={pickupForm.estimated_weight} onChange={(e) => setPickupForm({ ...pickupForm, estimated_weight: Number(e.target.value) })} /><Button onClick={() => runAction('Create pickup', createPickup)}>Create Pickup</Button></div>
      <div className="grid gap-2 md:grid-cols-6"><select className="h-10 rounded-xl border bg-background px-3 text-sm" value={factoryRequestForm.commodity_id} onChange={(e) => setFactoryRequestForm({ ...factoryRequestForm, commodity_id: e.target.value })}>{data.commodities.map((m) => <option key={m.id} value={m.id}>{m.title}</option>)}</select><select className="h-10 rounded-xl border bg-background px-3 text-sm" value={factoryRequestForm.preferred_grade} onChange={(e) => setFactoryRequestForm({ ...factoryRequestForm, preferred_grade: e.target.value })}><option>A</option><option>B</option><option>C</option></select><Input type="number" value={factoryRequestForm.quantity_kg} onChange={(e) => setFactoryRequestForm({ ...factoryRequestForm, quantity_kg: Number(e.target.value) })} /><Input type="date" value={factoryRequestForm.preferred_delivery_date} onChange={(e) => setFactoryRequestForm({ ...factoryRequestForm, preferred_delivery_date: e.target.value })} /><Input value={factoryRequestForm.notes} onChange={(e) => setFactoryRequestForm({ ...factoryRequestForm, notes: e.target.value })} /><Button onClick={() => runAction('Create factory material request', createMaterialRequest)}>Create Request</Button></div>
    </CardContent></Card>


    <MiniTable onProfile={(item,title)=>setProfile({item,title})} title="Supplier questions / admin replies" icon={FileText} description="Supplier messages are stored in the database as activity logs. Replies notify the supplier immediately." items={data.adminMessages} columns={[{ label: 'Supplier', render: (m) => <><p className="font-semibold">{m.sender_name || `User #${m.user_id}`}</p><p className="text-xs text-muted-foreground">{m.sender_email}</p></> }, { label: 'Question', render: (m) => <span className="line-clamp-3 text-xs text-muted-foreground">{m.message || '—'}</span> }, { label: 'Status', render: (m) => <Badge className={statusClass(m.status || 'open')}>{m.status || 'open'}</Badge> }, { label: 'Reply', render: (m) => <Input value={replyDrafts[m.id] || ''} onChange={(e) => setReplyDrafts({ ...replyDrafts, [m.id]: e.target.value })} placeholder="Write admin reply..." /> }]} actions={(m) => <Button size="sm" variant="outline" onClick={() => runAction('Reply to supplier', () => replyToSupplierMessage(m.id))}><Send className="mr-1 h-3 w-3" /> Reply</Button>} />

    <MiniTable onProfile={(item,title)=>setProfile({item,title})} title="Users / Profiles" icon={UserPlus} description="Add, inspect, print and safely deactivate accounts." items={data.users} columns={[{ label: 'User', render: (u) => <><p className="font-semibold">{u.fname} {u.lname}</p><p className="text-xs text-muted-foreground">{u.email}</p></> }, { label: 'Role', render: (u) => <Badge variant="outline">{u.employee?.role || u.role}</Badge> }, { label: 'Company / License', render: (u) => u.supplier?.company_name || u.factoryProfile?.company_name || u.factory_profile?.company_name || u.employee?.driver_license_number || 'Internal account' }, { label: 'Status', render: (u) => <Badge className={statusClass(u.employee?.employment_status || (u.deleted_at ? 'terminated' : 'active'))}>{u.employee?.employment_status || (u.deleted_at ? 'terminated' : 'active')}</Badge> }]} actions={(u) => <>{!['super_admin'].includes(u.role) && <><Button size="sm" variant="outline" onClick={() => runAction('Edit user', () => quickEditUser(u))}>Edit</Button><Button size="sm" variant="outline" onClick={() => runAction('Deactivate user', () => platformV1.users.delete(u.id), `Deactivate ${u.email}? This will revoke access but keep audit records.`)}><Trash2 className="mr-1 h-3 w-3" /> Deactivate</Button></>}</>} />

    <div className="grid gap-4 xl:grid-cols-2"><MiniTable onProfile={(item,title)=>setProfile({item,title})} title="Applications / Registrations" icon={FileText} description="Approve converts the application into user + profile + active contract + notification." items={data.applications} columns={[{ label: 'Company', render: (a) => <><p className="font-semibold">{a.company_name}</p><p className="text-xs text-muted-foreground">{a.contact_name} · {a.email}</p></> }, { label: 'Role', key: 'role' }, { label: 'Material', render: (a) => a.required_commodity || 'Supplier materials' }, { label: 'Message', render: (a) => <span className="line-clamp-2 text-xs text-muted-foreground">{a.message || '—'}</span> }, { label: 'Status', render: (a) => <Badge className={statusClass(a.status)}>{a.status}</Badge> }]} actions={(a) => <><Button size="sm" onClick={() => runAction('Approve application', () => platformV1.applications.updateStatus(a.id, { status: 'approved' }))}><CheckCircle2 className="mr-1 h-3 w-3" /> Approve</Button><Button size="sm" variant="outline" onClick={() => runAction('Reject application', () => platformV1.applications.updateStatus(a.id, { status: 'rejected', rejection_reason: 'Not matching current accepted material policy.' }))}><XCircle className="mr-1 h-3 w-3" /> Reject</Button></>} /><MiniTable onProfile={(item,title)=>setProfile({item,title})} title="Materials and prices" icon={PackagePlus} items={data.commodities} columns={[{ label: 'Material', key: 'title' }, { label: 'Current price', render: (m) => `$${m.current_price?.price || m.current_price || '—'}` }, { label: 'Suppliers linked', render: (m) => data.contracts.filter((c) => c.party_type === 'supplier' && Number(c.commodity_id) === Number(m.id)).length }, { label: 'Factories linked', render: (m) => data.contracts.filter((c) => c.party_type === 'factory' && Number(c.commodity_id) === Number(m.id)).length }]} actions={(m) => <Button size="sm" variant="outline" onClick={() => { setPriceForm((f) => ({ ...f, commodity_id: m.id })); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>Set price above</Button>} /></div>

    <div className="grid gap-4 xl:grid-cols-2"><MiniTable onProfile={(item,title)=>setProfile({item,title})} title="Contracts" icon={FileText} description="Contracts connect suppliers/factories to materials and drive pickup/delivery workflows." items={data.contracts} columns={[{ label: 'Contract', render: (c) => `#${c.id}` }, { label: 'Party', render: (c) => `${c.party_type} #${c.party_id}` }, { label: 'Material', render: (c) => c.material_type || c.commodity?.title || `commodity #${c.commodity_id}` }, { label: 'Status', render: (c) => <Badge className={statusClass(c.status)}>{c.status}</Badge> }]} actions={(c) => <><Button size="sm" variant="outline" onClick={() => runAction('Activate contract', () => platformV1.contracts.status(c.id, 'active'))}>Activate</Button><Button size="sm" variant="outline" onClick={() => runAction('Terminate contract', () => platformV1.contracts.status(c.id, 'terminated'))}>Terminate</Button></>} /><MiniTable onProfile={(item,title)=>setProfile({item,title})} title="Pickups / Dispatch" icon={Truck} description="Create pickups, assign driver + truck, cancel scheduled tasks when needed." items={data.pickups} columns={[{ label: 'Pickup', render: (p) => `#${p.id}` }, { label: 'Supplier', render: (p) => p.supplier?.user ? `${p.supplier.user.fname} ${p.supplier.user.lname}` : `supplier #${p.supplier_user_id}` }, { label: 'Hub', render: (p) => p.hub?.location || `hub #${p.hub_id}` }, { label: 'Driver / Truck', render: (p) => `${p.driver?.user?.fname || 'Unassigned'} / ${p.truck?.plate_number || 'No truck'}` }, { label: 'Status', render: (p) => <Badge className={statusClass(p.status)}>{p.status}</Badge> }]} actions={(p) => <><select className="h-9 rounded-lg border bg-background px-2 text-xs" value={dispatchForm.driver_employee_id} onChange={(e) => setDispatchForm({ ...dispatchForm, driver_employee_id: e.target.value })}>{drivers.map((d) => <option key={d.id} value={d.id}>{d.fname} {d.lname}</option>)}</select><select className="h-9 rounded-lg border bg-background px-2 text-xs" value={dispatchForm.truck_id} onChange={(e) => setDispatchForm({ ...dispatchForm, truck_id: e.target.value })}>{availableTrucks.map((t) => <option key={t.id} value={t.id}>{t.plate_number} · {t.status}</option>)}</select><Button size="sm" variant="outline" disabled={String(p.status).toLowerCase() !== 'scheduled'} onClick={() => runAction('Dispatch pickup', () => dispatchPickup(p.id))}><Send className="mr-1 h-3 w-3" /> Dispatch</Button><Button size="sm" variant="outline" disabled={String(p.status).toLowerCase() !== 'scheduled'} onClick={() => runAction('Cancel pickup', () => platformV1.pickups.cancel(p.id), 'Cancel this pickup?')}>Cancel</Button></>} /></div>

    <div className="grid gap-4 xl:grid-cols-2"><MiniTable onProfile={(item,title)=>setProfile({item,title})} title="Hubs" icon={Warehouse} items={data.hubs} columns={[{ label: 'Hub', key: 'location' }, { label: 'Capacity', render: (h) => `${h.capacity || h.maxCapacityKg || 0} kg` }, { label: 'Manager employee', render: (h) => h.manager_employee_id || 'not assigned' }, { label: 'Linked materials', render: () => data.commodities.length }]} /><MiniTable onProfile={(item,title)=>setProfile({item,title})} title="Trucks" icon={Truck} items={data.trucks} columns={[{ label: 'Plate', key: 'plate_number' }, { label: 'Hub', render: (t) => data.hubs.find((h) => Number(h.id) === Number(t.hub_id))?.location || `hub #${t.hub_id}` }, { label: 'Type', key: 'truck_type' }, { label: 'Status', render: (t) => <Badge className={statusClass(t.status)}>{t.status}</Badge> }]} actions={(t) => <><Button size="sm" variant="outline" onClick={() => runAction('Set available', () => platformV1.trucks.updateStatus(t.id, 'available'))}>Available</Button><Button size="sm" variant="outline" onClick={() => runAction('Maintenance', () => platformV1.trucks.updateStatus(t.id, 'maintenance'))}>Maintenance</Button></>} /></div>

    <div className="grid gap-4 xl:grid-cols-2"><MiniTable onProfile={(item,title)=>setProfile({item,title})} title="Factory material requests" icon={PackagePlus} description="Notes, company details and workflow actions are shown here." items={Array.isArray(data.materialRequests) ? data.materialRequests : []} columns={[{ label: 'Request', render: (r) => `#${r.id}` }, { label: 'Factory', render: (r) => r.factory_name || `factory #${r.factory_user_id}` }, { label: 'Material', render: (r) => r.material || data.commodities.find((m) => Number(m.id) === Number(r.commodity_id))?.title || `#${r.commodity_id}` }, { label: 'Qty', render: (r) => `${r.quantity_kg} kg` }, { label: 'Notes / Details', render: (r) => <div className="max-w-[240px]"><p className="text-xs font-semibold">{r.company_details || '—'}</p><p className="text-xs text-muted-foreground line-clamp-2">{r.notes || r.rejection_reason || 'No notes'}</p></div> }, { label: 'Matched Hub', render: (r) => r.matched_hub || r.matched_hub_id || 'Waiting' }, { label: 'Status', render: (r) => <Badge className={statusClass(r.status)}>{r.status}</Badge> }]} actions={(r) => <><Button size="sm" variant="outline" disabled={! ['requested', 'cancelled'].includes(String(r.status).toLowerCase())} onClick={() => runAction('Match request', () => platformV1.factory.matchMaterialRequest(r.id))}><CheckCircle2 className="mr-1 h-3 w-3" /> Match</Button><Button size="sm" variant="outline" disabled={! ['matched', 'matched_reserved'].includes(String(r.status).toLowerCase())} onClick={() => runAction('Schedule delivery', () => platformV1.factory.scheduleMaterialRequest(r.id, { scheduled_date: r.preferred_delivery_date || new Date().toISOString() }))}><CalendarClock className="mr-1 h-3 w-3" /> Schedule</Button><Button size="sm" variant="outline" disabled={! ['scheduled', 'matched'].includes(String(r.status).toLowerCase())} onClick={() => runAction('Ship external delivery', () => platformV1.factory.shipMaterialRequest(r.id))}><BadgeDollarSign className="mr-1 h-3 w-3" /> Ship</Button><Button size="sm" variant="outline" disabled={String(r.status).toLowerCase() !== 'shipped'} onClick={() => runAction('Open 48h window', () => platformV1.factory.adminConfirmMaterialRequest(r.id))}><CheckCircle2 className="mr-1 h-3 w-3" /> Confirm Receipt</Button><Button size="sm" variant="outline" onClick={() => runAction('Reject request', () => platformV1.factory.rejectMaterialRequest(r.id, 'Declined by admin after review.'), 'Reject this request and release reserved stock?')}><XCircle className="mr-1 h-3 w-3" /> Reject</Button></>} /><MiniTable onProfile={(item,title)=>setProfile({item,title})} title="Invoices" icon={FileText} items={data.invoices} columns={[{ label: 'Invoice', render: (i) => i.invoice_number || `#${i.id}` }, { label: 'Party', render: (i) => `${i.party_type} #${i.party_id}` }, { label: 'Total', render: (i) => `$${i.total_amount || i.total || 0}` }, { label: 'Due', key: 'due_date' }, { label: 'Status', render: (i) => <Badge className={statusClass(i.status)}>{i.status}</Badge> }]} actions={(i) => <Button size="sm" variant="outline" disabled={String(i.status).toLowerCase() === 'paid'} onClick={() => runAction('Mark invoice paid', () => platformV1.invoices.markPaid(i.id))}>Mark paid</Button>} /></div>

    <div className="grid gap-4 xl:grid-cols-2"><MiniTable onProfile={(item,title)=>setProfile({item,title})} title="Outbound deliveries" icon={Truck} items={data.outbound} columns={[{ label: 'Delivery', render: (d) => `#${d.id}` }, { label: 'Hub', render: (d) => d.hub?.location || d.hub_id }, { label: 'Material', render: (d) => d.commodity?.title || d.commodity_id }, { label: 'Qty', render: (d) => `${d.quantity_kg} kg` }, { label: 'Status', render: (d) => <Badge className={statusClass(d.status)}>{d.status}</Badge> }]} actions={(d) => <Button size="sm" variant="outline" disabled={! ['scheduled', 'matched'].includes(String(d.status).toLowerCase())} onClick={() => runAction('Ship delivery', () => platformV1.outbound.ship(d.id))}>Ship</Button>} /><MiniTable onProfile={(item,title)=>setProfile({item,title})} title="Live notifications" icon={FileText} items={Array.isArray(data.notifications) ? data.notifications : []} columns={[{ label: 'Notification', render: (n) => <><p className="font-semibold">{n.data?.title || n.type}</p><p className="text-xs text-muted-foreground">{n.data?.message || '—'}</p></> }, { label: 'Read', render: (n) => <Badge className={statusClass(n.read_at ? 'confirmed' : 'pending')}>{n.read_at ? 'read' : 'unread'}</Badge> }, { label: 'Date', render: (n) => new Date(n.created_at).toLocaleString() }]} /></div>

    <ProfileDialog profile={profile} onClose={() => setProfile(null)} />
  </div>;
}
