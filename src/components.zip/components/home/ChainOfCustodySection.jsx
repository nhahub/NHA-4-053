import React from 'react';
import SectionHeader from '@/components/home/SectionHeader';

const flow = [
  'Supplier',
  'Driver Pickup',
  'Hub QA',
  'Baling',
  'Inventory',
  'Factory Buyer',
];

export default function ChainOfCustodySection() {
  return (
    <section className="bg-background py-16 sm:py-20" id="chain-of-custody">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-10 xl:px-16">
        <SectionHeader
          eyebrow="Chain of Custody"
          title="Trace Every Handoff from"
          highlight="Source to Factory"
          description="Every operation is timestamped, documented, and linked to verified batch records for transparent compliance."
          centered
        />
        <div className="mt-10 rounded-3xl border border-border/80 bg-card p-5 sm:p-8">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-6">
            {flow.map((step, index) => (
              <div
                key={step}
                className="rounded-2xl border border-border/70 bg-surface-soft p-4 text-center"
              >
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-text">Step {index + 1}</p>
                <p className="mt-1 text-sm font-bold text-main">{step}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
