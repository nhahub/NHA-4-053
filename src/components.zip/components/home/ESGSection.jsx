import React from 'react';
import { motion } from 'framer-motion';
import { Leaf, BarChart3, FileText, Globe } from 'lucide-react';
import ESGCard from '@/components/home/ESGCard';

const NATURE_IMG = '/materials/organic.svg';

const features = [
  { icon: Leaf, title: 'Carbon Tracking', desc: 'Estimate avoided emissions from every kilogram diverted from landfill.' },
  { icon: BarChart3, title: 'Impact Dashboards', desc: 'Monitor recovery rates, processed volumes, and ESG performance in real time.' },
  { icon: FileText, title: 'Compliance Reports', desc: 'Generate audit-ready documentation for suppliers, hubs, and industrial buyers.' },
  { icon: Globe, title: 'Circular Scoring', desc: 'Measure the circular value of materials across the full chain of custody.' },
];

export default function ESGSection() {
  return (
    <section id="esg" className="py-16 sm:py-24 relative overflow-hidden">
      <div className="absolute inset-0">
        <motion.img
          src={NATURE_IMG}
          alt="Nature recovery scene"
          className="w-full h-full object-cover"
          initial={{ scale: 1.14 }}
          whileInView={{ scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.2, ease: 'easeOut' }}
        />
        <div className="absolute inset-0 bg-[rgba(8,24,28,0.44)]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 xl:px-16">
        <div className="max-w-3xl">
          <span className="mb-3 block text-xs font-semibold tracking-[0.16em] uppercase text-white/90">ESG & Reporting</span>
          <h2 className="font-heading text-3xl sm:text-4xl font-bold mb-4 text-white">Sustainability Built Into <span className="text-gradient-gold">Every Transaction</span></h2>
          <p className="text-slate-100 mb-10 sm:mb-12 leading-relaxed">
            Track landfill diversion, carbon impact, recovery performance, and compliance documentation through verified operational data.
          </p>

          <div className="grid sm:grid-cols-2 gap-6">
            {features.map((feat, i) => (
              <motion.div
                key={feat.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, type: 'spring', stiffness: 110 }}
                whileHover={{ y: -6, scale: 1.02 }}
              >
                <ESGCard icon={feat.icon} title={feat.title} description={feat.desc} />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}