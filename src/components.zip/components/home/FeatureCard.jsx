import React from 'react';

export default function FeatureCard({ icon: Icon, title, description }) {
  return (
    <article className="rounded-2xl border border-border/80 bg-card p-5 shadow-sm transition-all duration-200 hover:-translate-y-1 hover:shadow-lg">
      <div className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/12">
        <Icon className="h-5 w-5 text-primary" />
      </div>
      <h3 className="font-heading text-lg font-bold text-main">{title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-secondary-text">{description}</p>
    </article>
  );
}
