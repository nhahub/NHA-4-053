import React from 'react';
import { motion } from 'framer-motion';
import { Truck, ClipboardCheck, Package, Factory } from 'lucide-react';
import ProcessStep from '@/components/home/ProcessStep';

const STEPS = [
  {
    icon: Truck,
    title: 'Source Collection',
    sub: 'Supplier Registration & Pickup',
    desc: 'Waste suppliers register materials, set pickup schedules, and request collection through a dedicated portal. The system matches them with certified drivers and optimized routes in real time.',
    detail: 'Digital pickup manifests · Route optimization · Real-time ETA tracking',
    iconBg: 'bg-blue-600',
    tagColor: 'bg-blue-50 border-blue-200 text-blue-700',
  },
  {
    icon: ClipboardCheck,
    title: 'Hub QA & Sorting',
    sub: 'Quality Assurance at Processing Hubs',
    desc: 'Every inbound shipment undergoes rigorous contamination testing, weight verification, and purity grading by hub managers. ISO-compliant certificates are issued for each accepted batch.',
    detail: 'Contamination scoring · Photographic evidence · ISO 14001 documentation',
    iconBg: 'bg-amber-500',
    tagColor: 'bg-amber-50 border-amber-200 text-amber-700',
  },
  {
    icon: Package,
    title: 'Baling & Inventory',
    sub: 'Processing, Baling & Inventory Entry',
    desc: 'Accepted materials are sorted, cleaned, baled, and assigned a unique batch ID with a verified purity grade. Each batch enters the live inventory system, instantly available for buyer discovery.',
    detail: 'Unique batch IDs · Purity grading · Smart inventory aging alerts',
    iconBg: 'bg-emerald-600',
    tagColor: 'bg-emerald-50 border-emerald-200 text-emerald-700',
  },
  {
    icon: Factory,
    title: 'Factory Offtake',
    sub: 'Industry Buyer Procurement & Delivery',
    desc: 'Industry buyers browse verified live inventory, reserve materials with transparent pricing, and schedule contract deliveries. Full traceability from source to factory gate is guaranteed.',
    detail: 'Verified pricing · Contract management · Delivery scheduling',
    iconBg: 'bg-slate-700',
    tagColor: 'bg-slate-50 border-slate-200 text-slate-700',
  },
];

export default function ProcessTimeline() {
  return (
    <section id="process" className="py-16 sm:py-24 bg-gradient-warm">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-10 xl:px-16">

        {/* Header */}
        <motion.div
          className="text-center mb-12 sm:mb-16"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.65 }}
        >
          <span className="gold-label mb-3 block">How It Works</span>
          <h2 className="font-heading text-3xl sm:text-4xl font-bold mb-5 text-foreground">
            Four Stages.{' '}
            <span className="text-gradient-gold">Complete Traceability.</span>
          </h2>
          <p className="text-base text-muted-foreground max-w-xl mx-auto leading-relaxed">
            Every kilogram is tracked from source extraction to factory delivery with a full chain-of-custody digital record. Nothing slips through — nothing goes undocumented.
          </p>
        </motion.div>

        {/* Steps — vertical clean list */}
        <div className="relative">
          {/* Vertical line */}
          <div className="hidden lg:block absolute left-[28px] top-6 bottom-6 w-0.5 bg-border" />

          <div className="space-y-8">
            {STEPS.map((step, i) => (
              <ProcessStep key={step.title} step={step} index={i} />
            ))}
          </div>
        </div>

        {/* Bottom callout */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55, delay: 0.2 }}
          className="mt-12 sm:mt-16 text-center bg-card rounded-3xl border border-border p-6 sm:p-10 shadow-sm"
        >
          <p className="text-base font-semibold text-foreground max-w-2xl mx-auto leading-relaxed">
            Every stage generates timestamped records, digital certificates, and ESG impact data —{' '}
            <span className="text-primary">a complete audit trail</span> that meets EU taxonomy and regional regulatory requirements.
          </p>
        </motion.div>
      </div>
    </section>
  );
}