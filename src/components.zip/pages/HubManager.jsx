import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '@/components/shared/Navbar';
import PaginatedList from '@/components/shared/PaginatedList';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RefreshCw, PackageCheck, Warehouse, Scale, Cuboid, CheckCircle2 } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { platformV1 } from '@/services/platformV1Service';
import { useToast } from '@/components/ui/use-toast';
import { getFriendlyError } from '@/lib/friendlyErrors';

function statusClass(status = '') {
  const s = String(status).toLowerCase();
  if (['completed', 'quality_checked'].includes(s)) return 'bg-emerald-50 text-emerald-700 border-emerald-200';
  if (['received', 'processing'].includes(s)) return 'bg-amber-50 text-amber-700 border-amber-200';
  if (['rejected'].includes(s)) return 'bg-red-50 text-red-700 border-red-200';
  return 'bg-slate-50 text-slate-700 border-slate-200';
}

export default function HubManager() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [queue, setQueue] = useState({ completed_pickups: [], inbound_records: [], hub: null });
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [qaForm, setQaForm] = useState({ tier1_weight: '', rejected_weight: '', tier2_weight: '', quality_score: 'A' });

  const canAccess = currentUser && currentUser.role === 'hub_manager';

  async function loadHubData() {
    if (!canAccess) return;
    setLoading(true);
    try {
      const data = await platformV1.hub.receivingQueue();
      setQueue(data || { completed_pickups: [], inbound_records: [], hub: null });
    } catch (error) {
      const friendly = getFriendlyError(error);
      toast({ title: friendly.title, description: friendly.description, variant: 'destructive', duration: 4000 });
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadHubData(); }, [currentUser?.platformId]);

  const contaminationRatio = useMemo(() => {
    const tier1 = Number(qaForm.tier1_weight || 0);
    const rejected = Number(qaForm.rejected_weight || 0);
    if (!tier1) return 0;
    return Math.min(1, Math.max(0, rejected / tier1));
  }, [qaForm]);

  const acceptedWeight = Number(qaForm.tier2_weight || 0);
  const completedPickups = queue.completed_pickups || [];
  const inboundRecords = queue.inbound_records || [];
  const completedInbound = inboundRecords.filter((r) => String(r.status).toLowerCase() === 'completed').length;
  const pendingQa = inboundRecords.filter((r) => ['received', 'quality_checked'].includes(String(r.status).toLowerCase())).length;
  const totalAccepted = inboundRecords.reduce((s, r) => s + Number(r.accepted_weight || 0), 0);
  const thresholdProgress = Math.min(100, (totalAccepted / 50000) * 100);

  async function runAction(title, action) {
    try {
      await action();
      toast({ title, description: 'Hub workflow updated successfully.', duration: 4000 });
      setSelectedRecord(null);
      await loadHubData();
    } catch (error) {
      const friendly = getFriendlyError(error);
      toast({ title: friendly.title, description: friendly.description, variant: 'destructive', duration: 4000 });
    }
  }

  async function receivePickup(pickupId) {
    await runAction('Inbound record created', () => platformV1.hub.createInbound({ pickup_id: pickupId }));
  }

  async function submitQuality() {
    if (!selectedRecord) return;
    await runAction('Quality check recorded', () => platformV1.hub.quality(selectedRecord.id, {
      tier1_weight: Number(qaForm.tier1_weight),
      tier2_weight: Number(qaForm.tier2_weight),
      contamination_ratio: contaminationRatio,
    }));
  }

  async function submitBale(record) {
    await runAction('Bale created and inventory updated', () => platformV1.hub.bale(record.id, { quality_score: qaForm.quality_score || 'A' }));
  }

  if (!canAccess) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="font-heading text-2xl font-bold mb-2">Access Denied</h2>
          <p className="text-muted-foreground mb-4">Please log in as Hub Manager to access this page.</p>
          <Button onClick={() => navigate('/login')} className="bg-gradient-wine text-white">Sign In</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-8">
          <div>
            <h1 className="font-heading text-2xl font-bold">Hub Manager Dashboard</h1>
            <p className="text-sm text-muted-foreground">Live receiving, QA, bale creation, and inventory updates from the platform service.</p>
          </div>
          <Button variant="outline" onClick={loadHubData} disabled={loading}><RefreshCw className="w-4 h-4 mr-2" /> Refresh</Button>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Ready to Receive</p><p className="text-2xl font-bold">{completedPickups.length}</p></CardContent></Card>
          <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Pending QA/Bale</p><p className="text-2xl font-bold">{pendingQa}</p></CardContent></Card>
          <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Completed Inbound</p><p className="text-2xl font-bold">{completedInbound}</p></CardContent></Card>
          <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Accepted Kg Progress</p><Progress className="mt-3" value={thresholdProgress} /></CardContent></Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><PackageCheck className="h-4 w-4" /> Completed pickups waiting for receiving</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <PaginatedList items={completedPickups} empty={<p className="text-sm text-muted-foreground">No completed driver pickups waiting for receiving.</p>}>
              {(p) => (
                <div key={p.id} className="rounded-xl border border-border/60 p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div><p className="font-semibold text-sm">Pickup #{p.id} · {p.contract?.commodity?.title || 'Material'}</p><p className="text-xs text-muted-foreground">Supplier: {p.supplier?.user ? `${p.supplier.user.fname} ${p.supplier.user.lname}` : `#${p.supplier_user_id}`} · {Number(p.estimated_weight || 0).toLocaleString()}kg</p></div>
                    <Button size="sm" onClick={() => receivePickup(p.id)} className="bg-gradient-primary text-white"><Warehouse className="h-3 w-3 mr-1" /> Receive</Button>
                  </div>
                </div>
              )}
              </PaginatedList>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Cuboid className="h-4 w-4" /> Inbound records / QA / Bales</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <PaginatedList items={inboundRecords} empty={<p className="text-sm text-muted-foreground">No inbound records yet. Receive a completed pickup first.</p>}>
              {(r) => (
                <div key={r.id} className="rounded-xl border border-border/60 p-4 space-y-3">
                  <div className="flex items-center justify-between gap-3"><div><p className="font-semibold text-sm">Inbound #{r.id} · {r.pickup?.contract?.commodity?.title || 'Material'}</p><p className="text-xs text-muted-foreground">Pickup #{r.pickup_id} · Accepted: {Number(r.accepted_weight || 0).toLocaleString()}kg · Bales: {r.bale_cubes?.length || 0}</p></div><Badge className={statusClass(r.status)}>{r.status}</Badge></div>
                  <div className="flex flex-wrap gap-2">
                    {String(r.status).toLowerCase() === 'received' && <Button size="sm" variant="outline" onClick={() => setSelectedRecord(r)}><Scale className="h-3 w-3 mr-1" /> Quality Check</Button>}
                    {String(r.status).toLowerCase() === 'quality_checked' && <Button size="sm" onClick={() => submitBale(r)} className="bg-emerald-600 text-white"><CheckCircle2 className="h-3 w-3 mr-1" /> Create Bale + Update Stock</Button>}
                  </div>
                </div>
              )}
              </PaginatedList>
            </CardContent>
          </Card>
        </div>
      </div>

      <Dialog open={!!selectedRecord} onOpenChange={() => setSelectedRecord(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>Quality Check — Inbound #{selectedRecord?.id}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Input type="number" placeholder="Tier 1 weight (kg)" value={qaForm.tier1_weight} onChange={(e) => setQaForm({ ...qaForm, tier1_weight: e.target.value })} />
            <Input type="number" placeholder="Rejected / contaminated weight (kg)" value={qaForm.rejected_weight} onChange={(e) => setQaForm({ ...qaForm, rejected_weight: e.target.value })} />
            <Input type="number" placeholder="Tier 2 accepted weight (kg)" value={qaForm.tier2_weight} onChange={(e) => setQaForm({ ...qaForm, tier2_weight: e.target.value })} />
            <Select value={qaForm.quality_score} onValueChange={(v) => setQaForm({ ...qaForm, quality_score: v })}>
              <SelectTrigger><SelectValue placeholder="Quality grade" /></SelectTrigger>
              <SelectContent><SelectItem value="A">Grade A</SelectItem><SelectItem value="B">Grade B</SelectItem><SelectItem value="C">Grade C</SelectItem><SelectItem value="reject">Reject</SelectItem></SelectContent>
            </Select>
            <div className="rounded-xl border border-border/60 p-3"><p className="text-sm">Contamination: <strong>{(contaminationRatio * 100).toFixed(2)}%</strong></p><p className="text-xs text-muted-foreground mt-1">Accepted weight: {acceptedWeight.toLocaleString()} kg</p></div>
            <Button className="w-full rounded-xl bg-gradient-primary text-white" onClick={submitQuality}>Save Quality Check</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
