import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '@/components/shared/Navbar';
import StatCard from '@/components/shared/StatCard';
import PaginatedList from '@/components/shared/PaginatedList';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ShoppingCart, Package, Clock, FileText, Building2, Calendar, Scale, Shield, RefreshCw, CheckCircle2, AlertTriangle, Eye, Factory, Users, Lock } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '@/lib/AuthContext';
import { platformV1 } from '@/services/platformV1Service';
import { useToast } from '@/components/ui/use-toast';
import { getFriendlyError } from '@/lib/friendlyErrors';

function statusClass(status = '') {
  const s = String(status).toLowerCase();
  if (['matched', 'matched_reserved', 'scheduled', 'confirmed', 'fulfilled', 'paid', 'delivered'].includes(s)) return 'bg-emerald-50 text-emerald-700 border-emerald-200';
  if (['requested', 'pending', 'draft', 'shipped'].includes(s)) return 'bg-amber-50 text-amber-700 border-amber-200';
  if (['rejected', 'cancelled', 'overdue', 'disputed'].includes(s)) return 'bg-red-50 text-red-700 border-red-200';
  return 'bg-slate-50 text-slate-700 border-slate-200';
}

export default function Industry() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [materials, setMaterials] = useState([]);
  const [requests, setRequests] = useState([]);
  const [deliveries, setDeliveries] = useState([]);
  const [showReserve, setShowReserve] = useState(null);
  const [materialProfile, setMaterialProfile] = useState(null);
  const [form, setForm] = useState({ quantity: '', meetingDate: '', notes: '', companyDetails: '' });

  const canAccess = currentUser && ['industry', 'factory'].includes(currentUser.role);

  async function loadFactoryData() {
    if (!canAccess) return;
    setLoading(true);
    try {
      const [marketplace, materialRequests, factoryDeliveries] = await Promise.allSettled([
        platformV1.marketplace.materials(),
        platformV1.factory.materialRequests(),
        platformV1.factory.deliveries(),
      ]);
      if (marketplace.status === 'fulfilled') setMaterials(Array.isArray(marketplace.value) ? marketplace.value : []);
      if (materialRequests.status === 'fulfilled') {
        const value = materialRequests.value;
        setRequests(Array.isArray(value) ? value : (value?.data || []));
      }
      if (factoryDeliveries.status === 'fulfilled') setDeliveries(Array.isArray(factoryDeliveries.value) ? factoryDeliveries.value : []);
    } catch (error) {
      const friendly = getFriendlyError(error);
      toast({ title: friendly.title, description: friendly.description, variant: 'destructive', duration: 4000 });
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadFactoryData(); }, [currentUser?.platformId]);

  const myInvoices = useMemo(() => {
    return requests.filter((r) => ['scheduled', 'fulfilled', 'matched', 'matched_reserved'].includes(String(r.status).toLowerCase()));
  }, [requests]);

  if (!canAccess) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="font-heading text-2xl font-bold mb-2">Access Denied</h2>
          <p className="text-muted-foreground mb-4">Please log in as Factory to access this page.</p>
          <Button onClick={() => navigate('/login')} className="bg-gradient-wine text-white">Sign In</Button>
        </div>
      </div>
    );
  }

  const handleReserve = async () => {
    if (!showReserve || !form.quantity || !form.meetingDate) {
      toast({ title: 'Check your information', description: 'Please enter the desired quantity and discussion date.', variant: 'destructive', duration: 4000 });
      return;
    }
    if (Number(form.quantity) > Number(showReserve.available_kg || showReserve.weight || 0)) {
      toast({ title: 'Quantity is too high', description: 'Please request a quantity within the available stock.', variant: 'destructive', duration: 4000 });
      return;
    }
    setLoading(true);
    try {
      await platformV1.factory.createMaterialRequest({
        commodity_id: showReserve.commodity_id,
        preferred_grade: showReserve.grade || 'A',
        quantity_kg: Number(form.quantity),
        preferred_delivery_date: form.meetingDate,
        company_details: form.companyDetails || `${currentUser.company || currentUser.name} - ${currentUser.sector || 'Manufacturing'}`,
        notes: form.notes,
      });
      toast({ title: 'Request submitted', description: 'Your request was sent to the platform and appears in Admin material requests.', duration: 4000 });
      setShowReserve(null);
      setForm({ quantity: '', meetingDate: '', notes: '', companyDetails: '' });
      await loadFactoryData();
    } catch (error) {
      const friendly = getFriendlyError(error);
      toast({ title: friendly.title, description: friendly.description, variant: 'destructive', duration: 4000 });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="font-heading text-2xl font-bold">Factory Portal</h1>
            <p className="text-sm text-muted-foreground">{currentUser.name} · {currentUser.company || 'Factory account'}</p>
          </div>
          <Button variant="outline" onClick={loadFactoryData} disabled={loading}><RefreshCw className="w-4 h-4 mr-2" /> Refresh Live Data</Button>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard title="Available Materials" value={materials.length} icon={Package} />
          <StatCard title="Material Requests" value={requests.length} icon={ShoppingCart} />
          <StatCard title="Outbound Deliveries" value={deliveries.length} icon={Shield} />
          <StatCard title="Matched" value={requests.filter(r => ['matched','matched_reserved','scheduled','fulfilled'].includes(String(r.status).toLowerCase())).length} icon={Clock} />
        </div>

        <Tabs defaultValue="browse" className="space-y-6">
          <TabsList className="bg-muted rounded-xl p-1 flex flex-wrap h-auto">
            <TabsTrigger value="browse" className="rounded-lg text-xs">Available Materials</TabsTrigger>
            <TabsTrigger value="reservations" className="rounded-lg text-xs">Material Requests</TabsTrigger>
            <TabsTrigger value="outbound" className="rounded-lg text-xs">Outbound Delivery</TabsTrigger>
            <TabsTrigger value="invoices" className="rounded-lg text-xs">Invoices</TabsTrigger>
            <TabsTrigger value="profile" className="rounded-lg text-xs">Company Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="browse">
            <PaginatedList items={materials} className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4" empty={<Card className="col-span-full p-12 text-center"><p className="text-muted-foreground">No marketplace materials were loaded. Make sure the platform service is running and inventory data is available.</p></Card>}>
              {(item, i) => (
                <motion.div key={item.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>
                  <Card className="overflow-hidden hover:shadow-xl transition-all group">
                    <div className="relative h-32 overflow-hidden">
                      <img src={item.image_url} alt={item.material} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/10 to-transparent" />
                      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                        <Badge variant="secondary" className="text-[10px] font-mono bg-white/90">{item.batchId}</Badge>
                        <Badge className="text-[10px] bg-emerald-50 text-emerald-700">Live stock</Badge>
                      </div>
                    </div>
                    <CardContent className="p-5">
                      <h3 className="font-bold text-base mb-1">{item.material}</h3>
                      <p className="text-xs text-muted-foreground mb-3">{item.hub}</p>
                      <div className="grid grid-cols-2 gap-y-2 text-xs text-muted-foreground mb-4">
                        <div className="flex items-center gap-1"><Scale className="w-3 h-3" /> {Number(item.available_kg).toLocaleString()}kg available</div>
                        <div className="flex items-center gap-1"><Lock className="w-3 h-3" /> {Number(item.reserved_kg || 0).toLocaleString()}kg reserved</div>
                        <div className="flex items-center gap-1"><Shield className="w-3 h-3" /> {item.purityGrade}</div>
                        <div>Price: <span className="text-foreground">${Number(item.price_per_kg).toFixed(2)}/kg</span></div>
                        <div className="flex items-center gap-1"><Users className="w-3 h-3" /> {item.supplier_count || 0} suppliers</div>
                        <div className="flex items-center gap-1"><Factory className="w-3 h-3" /> {item.factory_count || 0} factories</div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <Button variant="outline" onClick={() => setMaterialProfile(item)} className="rounded-xl text-xs">
                          <Eye className="w-3.5 h-3.5 mr-1.5" /> Profile
                        </Button>
                        <Button onClick={() => setShowReserve(item)} className="bg-gradient-wine text-white rounded-xl text-xs hover:opacity-90">
                          <ShoppingCart className="w-3.5 h-3.5 mr-1.5" /> Request
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </PaginatedList>
          </TabsContent>

          <TabsContent value="reservations">
            <PaginatedList items={requests} className="space-y-4" empty={<Card className="p-12 text-center"><p className="text-muted-foreground">No material requests yet.</p></Card>}>
              {(res) => (
                <Card key={res.id} className="overflow-hidden">
                  <CardContent className="p-5">
                    <div className="flex items-center justify-between gap-4">
                      <div>
                        <h3 className="font-semibold text-sm">{res.material || `Commodity #${res.commodity_id}`}</h3>
                        <p className="text-xs text-muted-foreground">Request #{res.id} · {Number(res.quantity_kg).toLocaleString()}kg · Preferred date: {res.preferred_delivery_date || 'not selected'}</p>
                        <p className="text-xs text-muted-foreground mt-1">Matched Hub: {res.matched_hub || 'Waiting for stock match'}</p>
                      </div>
                      <Badge variant="outline" className={statusClass(res.status)}>{res.status}</Badge>
                    </div>
                  </CardContent>
                </Card>
              )}
            </PaginatedList>
          </TabsContent>

          <TabsContent value="outbound">
            <PaginatedList items={deliveries} className="space-y-4" empty={<Card className="p-12 text-center"><p className="text-muted-foreground">No outbound deliveries yet.</p></Card>}>
              {(delivery) => (
                <Card key={delivery.id} className="overflow-hidden">
                  <CardContent className="p-5">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold text-sm">Delivery #{delivery.id} · {delivery.commodity?.title || delivery.material || 'Material'}</h3>
                        <p className="text-xs text-muted-foreground">Quantity: {delivery.quantity_kg || delivery.allocatedQty}kg · Scheduled: {delivery.scheduled_date || delivery.eta}</p>
                      </div>
                      <Badge variant="outline" className={statusClass(delivery.status)}>{delivery.status}</Badge>
                    </div>
                    <div className="mt-3 flex gap-2">
                      <Button size="sm" className="h-7 text-xs bg-gradient-primary text-white" onClick={async () => { await platformV1.factory.confirmDelivery(delivery.id); await loadFactoryData(); }}><CheckCircle2 className="w-3 h-3 mr-1" /> Confirm Receipt</Button>
                      <Button size="sm" variant="outline" className="h-7 text-xs" onClick={async () => { await platformV1.factory.rejectDelivery(delivery.id, 'Rejected during the 48-hour factory review window.'); await loadFactoryData(); }}><AlertTriangle className="w-3 h-3 mr-1" /> Reject During 48h Window</Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </PaginatedList>
          </TabsContent>

          <TabsContent value="invoices">
            <PaginatedList items={myInvoices} className="space-y-4" empty={<Card className="p-12 text-center"><p className="text-muted-foreground">No invoice-ready requests yet.</p></Card>}>
              {(res) => (
                <Card key={res.id} className="overflow-hidden">
                  <CardContent className="p-5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center"><FileText className="w-5 h-5 text-primary" /></div>
                        <div>
                          <p className="font-semibold text-sm">Invoice Preview #{res.id}</p>
                          <p className="text-xs text-muted-foreground">{res.material} · {Number(res.quantity_kg).toLocaleString()}kg · generated after delivery confirmation</p>
                        </div>
                      </div>
                      <div className="text-right"><Badge className="text-[10px] bg-green-50 text-green-700">{res.status}</Badge></div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </PaginatedList>
          </TabsContent>

          <TabsContent value="profile">
            <Card>
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-wine flex items-center justify-center"><Building2 className="w-8 h-8 text-white" /></div>
                  <div><h3 className="font-bold text-lg">{currentUser.name}</h3><p className="text-sm text-muted-foreground">{currentUser.company || 'Factory account'}</p></div>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div><span className="text-muted-foreground text-xs">Email</span><p className="font-medium">{currentUser.email}</p></div>
                  <div><span className="text-muted-foreground text-xs">Phone</span><p className="font-medium">{currentUser.phone || '—'}</p></div>
                  <div><span className="text-muted-foreground text-xs">Location</span><p className="font-medium">{currentUser.location || '—'}</p></div>
                  <div><span className="text-muted-foreground text-xs">Sector</span><p className="font-medium">{currentUser.sector || 'Manufacturing'}</p></div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <Dialog open={!!materialProfile} onOpenChange={() => setMaterialProfile(null)}>
          <DialogContent className="sm:max-w-2xl">
            <DialogHeader><DialogTitle className="font-heading">Material Profile</DialogTitle></DialogHeader>
            {materialProfile && (
              <div className="space-y-4">
                <div className="relative h-44 overflow-hidden rounded-2xl border">
                  <img src={materialProfile.image_url} alt={materialProfile.material} className="h-full w-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4 text-white">
                    <h3 className="text-xl font-bold">{materialProfile.material}</h3>
                    <p className="text-sm text-white/80">{materialProfile.hub} · {materialProfile.batchId}</p>
                  </div>
                </div>
                <div className="grid gap-3 sm:grid-cols-3">
                  <div className="rounded-xl border p-3"><p className="text-xs text-muted-foreground">Available</p><p className="font-bold">{Number(materialProfile.available_kg).toLocaleString()}kg</p></div>
                  <div className="rounded-xl border p-3"><p className="text-xs text-muted-foreground">Reserved</p><p className="font-bold">{Number(materialProfile.reserved_kg || 0).toLocaleString()}kg</p></div>
                  <div className="rounded-xl border p-3"><p className="text-xs text-muted-foreground">Grade</p><p className="font-bold">{materialProfile.purityGrade}</p></div>
                  <div className="rounded-xl border p-3"><p className="text-xs text-muted-foreground">Price</p><p className="font-bold">${Number(materialProfile.price_per_kg).toFixed(2)}/kg</p></div>
                  <div className="rounded-xl border p-3"><p className="text-xs text-muted-foreground">Suppliers</p><p className="font-bold">{materialProfile.supplier_count || 0}</p></div>
                  <div className="rounded-xl border p-3"><p className="text-xs text-muted-foreground">Factories</p><p className="font-bold">{materialProfile.factory_count || 0}</p></div>
                </div>
                <div className="rounded-2xl border bg-emerald-50 p-4 text-sm text-emerald-900">
                  {materialProfile.impact_note || 'This material is connected to live inventory, supplier contracts, factory requests and reserved stock.'}
                </div>
                <Button onClick={() => { setShowReserve(materialProfile); setMaterialProfile(null); }} className="w-full rounded-xl bg-gradient-wine text-white">Request this material</Button>
              </div>
            )}
          </DialogContent>
        </Dialog>

        <Dialog open={!!showReserve} onOpenChange={() => setShowReserve(null)}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader><DialogTitle className="font-heading">Request Material</DialogTitle></DialogHeader>
            {showReserve && (
              <div className="space-y-4 mt-2">
                <div className="p-3 rounded-xl bg-muted/50 border"><p className="font-semibold text-sm">{showReserve.material}</p><p className="text-xs text-muted-foreground">{showReserve.batchId} · {Number(showReserve.available_kg).toLocaleString()}kg available · {showReserve.purityGrade}</p></div>
                <div><Label className="text-xs">Desired Quantity (kg) *</Label><Input type="number" value={form.quantity} onChange={e => setForm({ ...form, quantity: e.target.value })} placeholder={`Max: ${showReserve.available_kg}`} className="h-10 rounded-xl" /></div>
                <div><Label className="text-xs">Discussion Date *</Label><Input type="date" value={form.meetingDate} onChange={e => setForm({ ...form, meetingDate: e.target.value })} className="h-10 rounded-xl" /></div>
                <div><Label className="text-xs">Company Details</Label><Input value={form.companyDetails} onChange={e => setForm({ ...form, companyDetails: e.target.value })} placeholder="Company name & sector" className="h-10 rounded-xl" /></div>
                <div><Label className="text-xs">Notes</Label><Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Additional requirements..." rows={3} className="rounded-xl" /></div>
                <Button onClick={handleReserve} disabled={loading} className="w-full h-11 rounded-xl bg-gradient-wine text-white hover:opacity-90 font-semibold"><Calendar className="w-4 h-4 mr-2" /> Submit Request</Button>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
