import { request, unwrapData } from '@/services/authService';

const API = '/api/v1';

function buildQuery(params = {}) {
  const query = new URLSearchParams();
  Object.entries(params || {}).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') query.set(key, value);
  });
  const text = query.toString();
  return text ? `?${text}` : '';
}

function unwrapList(response) {
  const data = unwrapData(response);
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.data)) return data.data;
  return [];
}

export const platformV1 = {
  unwrapList,
  buildQuery,

  dashboard: {
    summary: () => request(`${API}/dashboard/summary`).then(unwrapData),
    impact: () => request(`${API}/dashboard/impact`).then(unwrapData),
  },

  adminLive: {
    snapshot: (params = {}) =>
      request(`${API}/admin/live-snapshot${buildQuery(params)}`).then(unwrapData),
  },

  adminMessages: {
    list: (params = {}) =>
      request(`${API}/admin/messages${buildQuery({ status: 'open', per_page: 10, ...params })}`).then(unwrapList),

    reply: (id, payload = {}) => {
      const body =
        typeof payload === 'string'
          ? { reply: payload }
          : { reply: payload.reply ?? payload.message ?? payload.text ?? '' };

      return request(`${API}/admin/messages/${id}/reply`, {
        method: 'POST',
        body: JSON.stringify(body),
      }).then(unwrapData);
    },
  },

  supplier: {
    materials: (params = {}) =>
      request(`${API}/supplier/materials${buildQuery({ per_page: 10, ...params })}`).then(unwrapList),

    pickups: (params = {}) =>
      request(`${API}/supplier/pickups${buildQuery({ per_page: 10, ...params })}`).then(unwrapList),

    requestPickup: (payload) =>
      request(`${API}/supplier/pickup-requests`, {
        method: 'POST',
        body: JSON.stringify(payload),
      }).then(unwrapData),

    messageAdmin: (payload) => {
      const body =
        typeof payload === 'string'
          ? { message: payload }
          : {
              subject: payload.subject ?? null,
              message: payload.message ?? payload.text ?? '',
            };

      return request(`${API}/supplier/messages`, {
        method: 'POST',
        body: JSON.stringify(body),
      }).then(unwrapData);
    },
  },

  users: {
    list: (params = {}) =>
      request(`${API}/admin/users${buildQuery({ per_page: 200, sort: 'latest', ...params })}`).then(unwrapList),
    show: (id) => request(`${API}/admin/users/${id}`).then(unwrapData),
    create: (payload) => request(`${API}/admin/users`, { method: 'POST', body: JSON.stringify(payload) }),
    update: (id, payload) => request(`${API}/admin/users/${id}`, { method: 'PATCH', body: JSON.stringify(payload) }),
    updateStatus: (id, status) =>
      request(`${API}/admin/users/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ employment_status: status }),
      }),
    delete: (id) => request(`${API}/admin/users/${id}`, { method: 'DELETE' }),
  },

  notifications: {
    list: (params = {}) => request(`${API}/notifications${buildQuery({ per_page: 8, ...params })}`).then(unwrapData),
    markRead: (id) => request(`${API}/notifications/${id}/read`, { method: 'PATCH' }),
    markAllRead: () => request(`${API}/notifications/read-all`, { method: 'PATCH' }),
  },

  pickups: {
    list: (params = {}) =>
      request(`${API}/admin/pickups${buildQuery({ per_page: 200, sort: 'latest', ...params })}`).then(unwrapList),
    create: (payload) => request(`${API}/admin/pickups`, { method: 'POST', body: JSON.stringify(payload) }),
    cancel: (id) => request(`${API}/admin/pickups/${id}/cancel`, { method: 'PATCH' }),
    dispatch: (id, payload = {}) =>
      request(`${API}/admin/pickups/${id}/dispatch`, {
        method: 'PATCH',
        body: JSON.stringify({
          driver_employee_id:
            payload.driver_employee_id ?? payload.driver_id ?? payload.employee_id ?? payload.driver,
          truck_id: payload.truck_id ?? payload.vehicle_id ?? payload.truck,
        }),
      }).then(unwrapData),
  },

  trucks: {
    list: (params = {}) =>
      request(`${API}/admin/trucks${buildQuery({ per_page: 200, sort: 'latest', ...params })}`).then(unwrapList),
    show: (id) => request(`${API}/admin/trucks/${id}`).then(unwrapData),
    create: (payload) => request(`${API}/admin/trucks`, { method: 'POST', body: JSON.stringify(payload) }),
    update: (id, payload) => request(`${API}/admin/trucks/${id}`, { method: 'PATCH', body: JSON.stringify(payload) }),
    updateStatus: (id, status) =>
      request(`${API}/admin/trucks/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),
  },

  hubs: {
    list: (params = {}) => request(`${API}/admin/hubs${buildQuery({ per_page: 10, ...params })}`).then(unwrapList),
    show: (id) => request(`${API}/admin/hubs/${id}`).then(unwrapData),
    create: (payload) => request(`${API}/admin/hubs`, { method: 'POST', body: JSON.stringify(payload) }),
    update: (id, payload) => request(`${API}/admin/hubs/${id}`, { method: 'PATCH', body: JSON.stringify(payload) }),
    delete: (id) => request(`${API}/admin/hubs/${id}`, { method: 'DELETE' }),
  },

  commodities: {
    list: (params = {}) =>
      request(`${API}/admin/commodities${buildQuery({ per_page: 10, ...params })}`).then(unwrapList),
    show: (id) => request(`${API}/admin/commodities/${id}`).then(unwrapData),
    create: (payload) => request(`${API}/admin/commodities`, { method: 'POST', body: JSON.stringify(payload) }),
    update: (id, payload) =>
      request(`${API}/admin/commodities/${id}`, { method: 'PATCH', body: JSON.stringify(payload) }),
    setPrice: (id, price) =>
      request(`${API}/admin/commodities/${id}/prices`, {
        method: 'POST',
        body: JSON.stringify({ price }),
      }),
  },

  applications: {
    list: (params = {}) =>
      request(`${API}/admin/applications${buildQuery({ per_page: 10, ...params })}`).then(unwrapList),
    updateStatus: (id, payload) =>
      request(`${API}/admin/applications/${id}/status`, { method: 'PATCH', body: JSON.stringify(payload) }),
  },

  contracts: {
    list: (params = {}) =>
      request(`${API}/admin/contracts${buildQuery({ per_page: 10, ...params })}`).then(unwrapList),
    update: (id, payload) =>
      request(`${API}/admin/contracts/${id}`, { method: 'PATCH', body: JSON.stringify(payload) }),
    status: (id, status) =>
      request(`${API}/admin/contracts/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),
  },

  outbound: {
    list: (params = {}) =>
      request(`${API}/admin/outbound${buildQuery({ per_page: 10, ...params })}`).then(unwrapList),
    ship: (id) => request(`${API}/admin/outbound/${id}/ship`, { method: 'PATCH' }),
  },

  invoices: {
    list: (params = {}) =>
      request(`${API}/admin/invoices${buildQuery({ per_page: 10, ...params })}`).then(unwrapList),
    markPaid: (id) => request(`${API}/admin/invoices/${id}/mark-paid`, { method: 'PATCH' }),
  },

  driver: {
    pickups: (params = {}) =>
      request(`${API}/driver/pickups${buildQuery({ per_page: 200, sort: 'latest', ...params })}`).then(unwrapList),
    start: (id) => request(`${API}/driver/pickups/${id}/start`, { method: 'PATCH' }),
    recordWeight: (id, estimated_weight) =>
      request(`${API}/driver/pickups/${id}/weight`, {
        method: 'PATCH',
        body: JSON.stringify({ estimated_weight }),
      }),
    departToHub: (id) => request(`${API}/driver/pickups/${id}/depart-to-hub`, { method: 'PATCH' }),
    complete: (id, payload = {}) =>
      request(`${API}/driver/pickups/${id}/complete`, {
        method: 'PATCH',
        body: JSON.stringify(payload),
      }),
    reportProblem: (id, payload) =>
      request(`${API}/driver/pickups/${id}/problem-reports`, {
        method: 'POST',
        body: JSON.stringify(payload),
      }),
  },

  factory: {
    deliveries: (params = {}) =>
      request(`${API}/factory/deliveries${buildQuery({ per_page: 10, ...params })}`).then(unwrapList),
    confirmDelivery: (id) => request(`${API}/factory/deliveries/${id}/confirm`, { method: 'PATCH' }),
    rejectDelivery: (id, rejection_reason) =>
      request(`${API}/factory/deliveries/${id}/reject`, {
        method: 'POST',
        body: JSON.stringify({ rejection_reason }),
      }),
  },
};
